
let randomNum = Math.round( Math.random() * 99) + 1;
console.log(randomNum);
let counter = 1;

function sendData(myform) {
    guessNum = myform.inputbox.value;
if (guessNum == randomNum) {
     alert ("You guessed correct!"); 
     alert ("YOU are the smartest person alive!! It took you " + counter + " tries!");
    window.alert("Your mom and dad must be so proud of you!");
    myform.inputbox.value = " ";
   
} else if (guessNum < randomNum) {
    alert ("The number you guessed is too small!");
    counter += 1
    myform.inputbox.value = " ";
} else if (guessNum > randomNum) {
    alert ("The number you guessed is too big!");
    counter += 1;
    myform.inputbox.value = " ";
}
else if (guessNum = isNaN) {
    alert ("invalid.");
    counter += 1;
    myform.inputbox.value = " ";
}
else if(guessNum > randomNum) {
    alert ("invalid.");
    counter += 1;
    myform.inputbox.value = " ";
}
}
